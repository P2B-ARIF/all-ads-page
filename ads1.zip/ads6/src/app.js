// if(!a.endsWith(`${localStorage.getItem("pageView")}.html`)){
// 	window.location.href = `./../pages/page${localStorage.getItem(
// 		"pageView",
// 	)}.html`;
// }

// let a = window.location.href;
// let b = a.endsWith(`${localStorage.getItem("pageView")}.html`);
// if(b === false){
// window.location.href = "./../pages/page1.html"
// }
// console.log(b , "hi");
// console.log(, "hi");

const securePage = () => {
	let currentURL = window.location.href;
	let checkURL = currentURL.endsWith(
		`${localStorage.getItem("pageView")}.html`,
	);
	if (checkURL === false) {
		window.location.href = "./../pages/page1.html";
		localStorage.setItem("pageView", 1);
	}
};

// ? ads token save in localStorage
const saveToken = () => {
	const token = window.location.href.split("?token=");
	if (token[1]) {
		localStorage.setItem("_ads_token", `Bearer ${token[1]}`);
	}
};
saveToken();

const handleRightPage = () => {
	localStorage.setItem("pageView", 1);
	window.location.href = `./../ads6/pages/page${localStorage.getItem(
		"pageView",
	)}.html`;
};

const handlePageChange = () => {
	let currentURL = window.location.href;
	let checkURL = currentURL.endsWith(
		`${localStorage.getItem("pageView")}.html`,
	);
	if (checkURL === false) {
		window.location.href = "./../pages/page1.html";
	}

	let getPage = localStorage.getItem("pageView");
	let setPage = localStorage.setItem(
		"pageView",
		(getPage = parseInt(getPage) + 1),
	);
	console.log(setPage);
	window.location.href = `./../pages/page${localStorage.getItem(
		"pageView",
	)}.html`;
};

const handleNextBtn1 = () => {
	securePage();

	let check2 = document.getElementById("check2");
	check2.removeAttribute("disabled");
};

const handleNextBtn2 = () => {
	securePage();

	let check3 = document.getElementById("check3");
	check3.removeAttribute("disabled");
};

const handleNextBtn3 = () => {
	securePage();

	let check4 = document.getElementById("check4");
	check4.removeAttribute("disabled");
};

const handleNextBtn4 = () => {
	securePage();

	let nextBtn1 = document.getElementById("nextBtn1");
	nextBtn1.removeAttribute("disabled");
};

const imageClick = () => {
	console.log("object");
	let nextBtn = document.getElementById("nextBtnContainer");
	console.log(nextBtn);
	nextBtn.innerHTML = `
			<button
				id="nextBtn1"
				disabled
				onclick="handlePageChange()"
				type="button"
				class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700"
			>
				<i class="fa-solid fa-chevron-right mr-2"></i>
				Next
			</button>
`;
};

const imageClickSubmit = () => {
	console.log("object");
	let submitBtn = document.getElementById("submitBtnContainer");
	console.log(submitBtn);
	submitBtn.innerHTML = `
			<button
				id="nextBtn1"
				disabled
				onclick="handleSubmit()"
				type="button"
				class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700"
			>
				<i class="fa-solid fa-chevron-right mr-2"></i>
				Submit
			</button>
`;
};

const handleSubmit = () => {
	console.log("submit");

	const adsToken = localStorage.getItem("_ads_token");
	const adsLink = window.location.href;
	if (adsToken) {
		fetch("http://localhost:5000/user/ads/earnings-leaf", {
			method: "PUT",
			headers: {
				authentication: adsToken,
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ adsLink }),
		})
			.then(res => res.json())
			.then(data => {
				window.location.href = "http://localhost:3000/dashboard/workplace";
				console.log(data, "data ads");
			});
	}
};
