const sliderImage = [
	"https://thumbs.dreamstime.com/b/hand-coin-tree-tree-grows-pile-saving-money-future-investment-ideas-business-growth-green-background-111124211.jpg",
	"https://images.news18.com/ibnlive/uploads/2021/11/australian-woman-wins-one-million-1-16363496184x3.png",
	"https://www.jeffbullas.com/wp-content/uploads/2020/06/The-Ultimate-Guide-to-Making-Money-Online-in-2020.jpg",
];
let slider_image = document.getElementById("slider_image");
let slideCount = 0;
slider_image.setAttribute("src", sliderImage[slideCount]);

setInterval(() => {
    if (slideCount === -1) {
		slideCount = 2;
	}
    if (slideCount >= sliderImage.length) {
		slideCount = 0;
	}
    slider_image.setAttribute("src", sliderImage[slideCount]);
	slideCount++;
}, 5000);

const handleLeft = () => {
	if (slideCount === -1) {
		slideCount = 2;
	}
	slider_image.setAttribute("src", sliderImage[slideCount]);
	slideCount = slideCount - 1;
};
const handleRight = () => {
	if (slideCount >= sliderImage.length) {
		slideCount = 0;
	}
	slider_image.setAttribute("src", sliderImage[slideCount]);
	slideCount++;
};
